enum ProductType {
  Skate = 'Skate',
  Skirt = 'Skirt'
}

interface Product {
  type: ProductType;
  getPrice(): number;
}

interface Factory {
  createProduct(name): Product;
}

class Skate implements Product {
  type: ProductType = ProductType.Skate;

  getPrice(): number {
    return 25;
  }
}

class Skirt implements Product {
  type: ProductType = ProductType.Skirt;

  getPrice(): number {
    return 50;
  }
}

class ProductFactory implements Factory {
  createProduct(type: ProductType): Product {
    switch (type) {
      case ProductType.Skate:
        return new Skate();
      case ProductType.Skirt:
        return new Skirt();
      default:
        return null;
    }
  }
}

// USE

  const product = (new ProductFactory()).createProduct(ProductType.Skate);
  product.getPrice();