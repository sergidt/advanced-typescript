class CPU {
  processData() { }
}

class Memory {
  load() { }
}

class HardDrive {
  readData(scriptPath: string) { }
}


/* Facade */
class Program {
  private cpu: CPU;
  private memory: Memory;
  private hardDrive: HardDrive;

  constructor(private scriptPath: string) {
    this.cpu = new CPU();
    this.memory = new Memory();
    this.hardDrive = new HardDrive();
  }

  run() {
    this.hardDrive.readData(this.scriptPath);
    this.cpu.processData();
    this.memory.load();
  }
}


class User {
  executeProgram() {
    const program: Program = new Program('./script');
    program.run();
  }
}